from fastapi import FastAPI, WebSocket, Request, HTTPException
from fastapi.responses import StreamingResponse
import httpx
from contextlib import asynccontextmanager
from datetime import datetime
import asyncio
from uuid import uuid4
import re

img_tag_pattern = re.compile(r'<img[^>]+src="([^"]+)"[^>]*>', re.IGNORECASE)

from getChatId import main as get_messages  # This function fetches messages

active_clients = []
url_mappings = {}
messages = []
last_update = datetime.now()

async def send_periodic_updates():
    global messages
    while True:
        messages = get_messages() or []
        for message in messages:
            html = message.get("body", {}).get("content", "")

            # Replace all <img src="..."> with proxy path
            def replace_img(match):
                real_url = match.group(1)
                if "$value" in real_url:  # only rewrite Graph-hosted image
                    uid = str(uuid4())
                    url_mappings[uid] = real_url
                    return match.group(0).replace(real_url, f"/image-proxy?id={uid}")
                return match.group(0)

            new_html = img_tag_pattern.sub(replace_img, html)
            message["body"]["content"] = new_html  # overwrite with cleaned html
                    message["text"] = message["text"].replace(img, url_mappings[img])
        for client in active_clients.copy():
            try:
                await client.send_json(messages)
            except Exception as e:
                print(f"Error sending periodic update: {e}")
                active_clients.remove(client)
        await asyncio.sleep(60)

@asynccontextmanager
async def lifespan(app: FastAPI):
    global messages
    messages = get_messages() or []  # initial preload
    background_task = asyncio.create_task(send_periodic_updates())
    yield
    background_task.cancel()

app = FastAPI(lifespan=lifespan)

@app.websocket("/ws/teams")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_clients.append(websocket)

    # Immediately send the latest messages on connect
    try:
        await websocket.send_json(messages)
        while True:
            await websocket.receive_text()  # keep alive
    except Exception as e:
        print(f"Client disconnected or error: {e}")
    finally:
        if websocket in active_clients:
            active_clients.remove(websocket)


@app.get("/image-proxy/")
async def image_proxy(request: Request):
    url = request.query_params.get("url")
    if not url:
        raise HTTPException(status_code=400, detail="Missing 'url' parameter")

    headers = {"Authorization": f"Bearer {ACCESS_TOKEN}"}
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, headers=headers)
        if resp.status_code != 200:
            raise HTTPException(status_code=resp.status_code, detail="Image fetch failed")
        return StreamingResponse(resp.aiter_bytes(), media_type=resp.headers.get("Content-Type", "image/png"))

# Only for manual running
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="localhost", port=8000)
