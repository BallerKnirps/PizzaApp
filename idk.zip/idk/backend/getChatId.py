import requests
import datetime

TENANT_ID = "30a03c1d-8b9f-437d-9680-205575f91380"
CLIENT_ID = "900bc9d9-6b51-4d61-8b4d-c6b54b906de2"
CLIENT_SECRET = "vxB8Q~yTEditdWwAX_GlM-uuEyhYOx1lOxH1Fb.y"

def get_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    data = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": "https://graph.microsoft.com/.default",
    }
    response = requests.post(url, data=data)
    response.raise_for_status()
    return response.json()["access_token"]

def get_chats(access_token):
    url = "https://graph.microsoft.com/v1.0/users/d6dc15f6-47e2-4786-a1d6-7b88d7bcf9dd/chats"
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()["value"]

def get_messages(access_token, chat_id):
    url = f"https://graph.microsoft.com/v1.0/chats/{chat_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()["value"]

def main():
    token = get_token()
    messages = get_messages(token, "19:c85ccb7c68164f918361586431268deb@thread.v2")
    print(messages[0])

    # filter for only today messages
    today = datetime.datetime.now().date()
    messages = [
        message for message in messages
        if datetime.datetime.fromisoformat(message["createdDateTime"]).date() == today
    ]
    return messages

if __name__ == "__main__":
    main()