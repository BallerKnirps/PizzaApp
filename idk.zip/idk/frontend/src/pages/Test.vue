<template>
    <MessageChat :messages="messages" />
</template>

<script setup>
import MessageChat from '@/components/MessageChat.vue'

import { ref, onBeforeUnmount, onMounted } from 'vue'

const messages = ref([])
const socket = ref(null);


onMounted(() => {
    connectWebSocket();
})

const connectWebSocket = () => {
  if (socket.value) {
    socket.value.close(); // Close any existing connection
  }

  // Connect to WebSocket server (adjust URL as needed)
  socket.value = new WebSocket('ws://localhost:8000/ws/teams');

  // Handle incoming messages
  socket.value.onmessage = (event) => {
    const res = JSON.parse(event.data); // Assuming the message is in JSON format
    console.log('Received message:', res);
    messages.value = res.sort((a, b) => {
      return new Date(a.createdDateTime) - new Date(b.createdDateTime);
    });
  };

  // Handle WebSocket errors
  socket.value.onerror = (error) => {
    console.error('WebSocket error:', error);
  };

  // Handle WebSocket closure
  socket.value.onclose = () => {
    console.log('WebSocket connection closed');
  };
};

// Cleanup WebSocket connection before the component is unmounted
onBeforeUnmount(() => {
  if (socket.value) {
    socket.value.close();
  }
});

</script>