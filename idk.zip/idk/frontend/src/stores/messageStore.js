import { defineStore } from 'pinia';

export const useMessageStore = defineStore('message', {
  state: () => ({
    messages: [],
    messageCount: 0,
    messageLimit: 100,
    }),
    getters: {
        getMessages: (state) => {
            return state.messages;
        }
    },
    actions: {
        addMessage(message) {
            this.messages.push(message);
            this.messageCount++;
            if (this.messages.length > this.messageLimit) {
                this.messages.shift();
            }
        },
        clearMessages() {
            this.messages = [];
            this.messageCount = 0;
        },
        removeMessage(index) {
            if (index >= 0 && index < this.messages.length) {
                this.messages.splice(index, 1);
                this.messageCount--;
            }
        }
    }
});