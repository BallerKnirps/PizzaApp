<template>
    <v-card class="mb-2" 
        :title="sender.user.displayName"
        :subtitle="created"
        >
        <p>
            {{ message }}
        </p>
    </v-card>
</template>
<script setup>
import { computed } from 'vue'

/*
example:
{'id': '1747995729027', 'replyToId': None, 'etag': '1747995735313', 'messageType': 'message', 'createdDateTime': '2025-05-23T10:22:09.027Z', 'lastModifiedDateTime': '2025-05-23T10:22:15.313Z', 'lastEditedDateTime': None, 'deletedDateTime': None, 'subject': None, 'summary': None, 'chatId': '19:c85ccb7c68164f918361586431268deb@thread.v2', 'importance': 'normal', 'locale': 'en-us', 'webUrl': None, 'channelIdentity': None, 'policyViolation': None, 'eventDetail': None, 'from': {'application': None, 'device': None, 'user': {'@odata.type': '#microsoft.graph.teamworkUserIdentity', 'id': 'd219487f-1889-470f-92b8-dcae410a0a27', 'displayName': 'Zühlke, Nico', 'userIdentityType': 'aadUser', 'tenantId': '30a03c1d-8b9f-437d-9680-205575f91380'}}, 'body': {'contentType': 'html', 'content': '<p>sind hinten im pausenraum</p>'}, 'attachments': [], 'mentions': [], 'reactions': [{'reactionType': 'like', 'displayName': 'like', 'reactionContentUrl': None, 'createdDateTime': '2025-05-23T10:22:15.333Z', 'user': {'application': None, 'device': None, 'user': {'@odata.type': '#microsoft.graph.teamworkUserIdentity', 'id': 'd6dc15f6-47e2-4786-a1d6-7b88d7bcf9dd', 'displayName': None, 'userIdentityType': 'aadUser', 'tenantId': '30a03c1d-8b9f-437d-9680-205575f91380'}}}]}


*/

const props = defineProps({
    message: {
        type: Object,
        required: true
    }
})

const sender = computed(() => props.message.from)

console.log(props.message)

const message = computed(() => extractContent(props.message.body.content))


const created = computed(() => props.message.createdDateTime)

    

function extractContent(s) {
  var span = document.createElement('span');
  span.innerHTML = s;
  return s
}
</script>

<style scoped>

p {
    margin: 0;
    padding: 0;
    margin-left: 30px;
    padding-bottom: 30px;
}



</style>