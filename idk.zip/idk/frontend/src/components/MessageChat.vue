<template>
    <ul>
        {{ console.log(messages) }}
        <li v-for="(message, index) in messages" :key="index">
            <Message :message="message" />
        </li>
    </ul>
</template>

<script setup>
import Message from '@/components/Message.vue'

const props = defineProps({
    messages: {
        type: Array,
        required: true
    }
})
</script>
<style scoped>
ul {
    list-style-type: none;
    padding: 0;
    width: 500px;
}

li {
    margin: 20px
}
</style>

